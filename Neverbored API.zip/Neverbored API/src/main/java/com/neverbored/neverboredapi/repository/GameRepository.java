package com.neverbored.neverboredapi.repository;

import com.neverbored.neverboredapi.model.Game;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GameRepository extends JpaRepository<Game, Long> {
}
