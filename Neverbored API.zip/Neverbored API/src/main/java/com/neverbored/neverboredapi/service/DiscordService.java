package com.neverbored.neverboredapi.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

@Service
public class DiscordService {

    private static final String DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1312338315546198027/Rj8Z9TBZi7Y6UT9Prr_kyKUDst5ss-3hO-eUKpkc9pIT0w1Of4M2e5YbUibIIxid_aXr"; // Replace with your actual Discord webhook URL

    public void postToDiscord(String message) {
        RestTemplate restTemplate = new RestTemplate();

        // Create the payload
        String jsonPayload = "{\"content\": \"" + message + "\"}";

        // Set headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        // Send the POST request
        HttpEntity<String> entity = new HttpEntity<>(jsonPayload, headers);
        restTemplate.exchange(DISCORD_WEBHOOK_URL, HttpMethod.POST, entity, String.class);
        System.out.println("Posted to Discord: " + message);
    }
}

