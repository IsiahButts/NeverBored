package com.neverbored.neverboredapi.scheduler;

import com.neverbored.neverboredapi.model.Game;
import com.neverbored.neverboredapi.model.Music;
import com.neverbored.neverboredapi.service.GameService;
import com.neverbored.neverboredapi.service.MusicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ScheduledTask {

    @Autowired
    private MusicService musicService;

    @Autowired
    private GameService gameService;

    @Scheduled(fixedRate = 3600000) // Every hour
    public void handleMusicUpdates() {
        Music newMusic = new Music();
        newMusic.setName("New Song");
        newMusic.setArtist("Artist");
        newMusic.setGenre("Pop");
        musicService.addMusic(newMusic);

        List<Music> allMusic = musicService.getAllMusic();
        if (!allMusic.isEmpty()) {
            musicService.deleteMusic(allMusic.get(0).getId());
        }
    }

    @Scheduled(fixedRate = 3600000) // Every hour
    public void handleGameUpdates() {
        Game newGame = new Game();
        newGame.setName("New Game");
        newGame.setGenre("Action");
        newGame.setPlatform("PC");
        gameService.addGame(newGame);

        List<Game> allGames = gameService.getAllGames();
        if (!allGames.isEmpty()) {
            gameService.deleteGame(allGames.get(0).getId());
        }
    }
}