package com.neverbored.neverboredapi.service;

import com.neverbored.neverboredapi.model.Game;
import com.neverbored.neverboredapi.repository.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

@Service
public class GameService {

    @Autowired
    private GameRepository gameRepository;

    @Autowired
    private DiscordService discordService;

    private Random random = new Random();

    @Scheduled(fixedRate = 5000)  // Runs every 5 seconds
    public void addOrUpdateOrDeleteGame() {
        int action = random.nextInt(3);  // Randomly choose between 0, 1, or 2 for add, update, or delete

        if (action == 0) {
            // Add a new game entry
            Game game = new Game();
            game.setGenre("Genre" + random.nextInt(10));
            game.setName("Game" + random.nextInt(1000));
            game.setPlatform("Platform" + random.nextInt(5));
            gameRepository.save(game);
            System.out.println("Added new game: " + game.getName());

            // Post to Discord
            discordService.postToDiscord("New game added: " + game.getName());

        } else if (action == 1) {
            // Update a random game entry
            List<Game> gameList = gameRepository.findAll();
            if (gameList != null && !gameList.isEmpty()) {
                Game game = gameList.get(random.nextInt(gameList.size()));
                game.setName("Updated Game" + random.nextInt(1000));
                gameRepository.save(game);
                System.out.println("Updated game: " + game.getName());

                // Post to Discord
                discordService.postToDiscord("Updated game: " + game.getName());
            }

        } else {
            // Delete a random game entry
            List<Game> gameList = gameRepository.findAll();
            if (gameList != null && !gameList.isEmpty()) {
                Game game = gameList.get(random.nextInt(gameList.size()));
                gameRepository.delete(game);
                System.out.println("Deleted game: " + game.getName());

                // Post to Discord
                discordService.postToDiscord("Deleted game: " + game.getName());
            }
        }
    }

    // Returns all game entries from the database
    public List<Game> getAllGames() {
        return gameRepository.findAll();  // Fetches all game entries from the database
    }

    // Add a game entry
    public Game addGame(Game game) {
        return gameRepository.save(game);
    }

    // Update a game entry by ID
    public Game updateGame(Long id, Game gameDetails) {
        Game game = gameRepository.findById(id).orElse(null);
        if (game != null) {
            game.setGenre(gameDetails.getGenre());
            game.setName(gameDetails.getName());
            game.setPlatform(gameDetails.getPlatform());
            return gameRepository.save(game);
        }
        return null;
    }

    // Delete a game entry by ID
    public void deleteGame(Long id) {
        gameRepository.deleteById(id);
    }
}
