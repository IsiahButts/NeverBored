package com.neverbored.neverboredapi.service;

import com.neverbored.neverboredapi.model.Music;
import com.neverbored.neverboredapi.repository.MusicRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

@Service
public class MusicService {

    @Autowired
    private MusicRepository musicRepository;

    @Autowired
    private DiscordService discordService;

    private Random random = new Random();

    @Scheduled(fixedRate = 5000)  // Runs every 5 seconds
    public void addOrUpdateOrDeleteMusic() {
        int action = random.nextInt(3);  // Randomly choose between 0, 1, or 2 for add, update, or delete

        if (action == 0) {
            // Add a new music entry
            Music music = new Music();
            music.setArtist("Artist" + random.nextInt(1000));
            music.setGenre("Genre" + random.nextInt(10));
            music.setName("Song" + random.nextInt(1000));
            musicRepository.save(music);
            System.out.println("Added new music: " + music.getName());

            // Post to Discord
            discordService.postToDiscord("New music added: " + music.getName());

        } else if (action == 1) {
            // Update a random music entry
            List<Music> musicList = musicRepository.findAll();
            if (musicList != null && !musicList.isEmpty()) {
                Music music = musicList.get(random.nextInt(musicList.size()));
                music.setName("Updated Song" + random.nextInt(1000));
                musicRepository.save(music);
                System.out.println("Updated music: " + music.getName());

                // Post to Discord
                discordService.postToDiscord("Updated music: " + music.getName());
            }

        } else {
            // Delete a random music entry
            List<Music> musicList = musicRepository.findAll();
            if (musicList != null && !musicList.isEmpty()) {
                Music music = musicList.get(random.nextInt(musicList.size()));
                musicRepository.delete(music);
                System.out.println("Deleted music: " + music.getName());

                // Post to Discord
                discordService.postToDiscord("Deleted music: " + music.getName());
            }
        }
    }

    // Returns all music entries from the database
    public List<Music> getAllMusic() {
        return musicRepository.findAll();  // Fetches all music entries from the database
    }

    // Add a music entry
    public Music addMusic(Music music) {
        return musicRepository.save(music);
    }

    // Update a music entry by ID
    public Music updateMusic(Long id, Music musicDetails) {
        Music music = musicRepository.findById(id).orElse(null);
        if (music != null) {
            music.setArtist(musicDetails.getArtist());
            music.setGenre(musicDetails.getGenre());
            music.setName(musicDetails.getName());
            return musicRepository.save(music);
        }
        return null;
    }

    // Delete a music entry by ID
    public void deleteMusic(Long id) {
        musicRepository.deleteById(id);
    }
}
