package com.neverbored.neverboredapi.controller;

import com.neverbored.neverboredapi.model.Music;
import com.neverbored.neverboredapi.service.MusicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/music")
public class MusicController {

    @Autowired
    private MusicService musicService;

    @GetMapping
    public List<Music> getAllMusic() {
        return musicService.getAllMusic();
    }

    @PostMapping
    public Music createMusic(@RequestBody Music music) {
        return musicService.addMusic(music);
    }

    @PutMapping("/{id}")
    public Music updateMusic(@PathVariable Long id, @RequestBody Music musicDetails) {
        return musicService.updateMusic(id, musicDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteMusic(@PathVariable Long id) {
        musicService.deleteMusic(id);
    }
}
